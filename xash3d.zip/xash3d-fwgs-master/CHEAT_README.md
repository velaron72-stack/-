# Xash3D FWGS + Engine Cheat (pre-patched)

Читы уже встроены в исходники. Собирай как обычно.

## Что сделано

- Добавлен `engine/client/cheat/` (ESP, Aimbot, Triggerbot, Touch GUI, Config)
- Хуки в:
  - `cl_game.c` — Cheat_Draw после HUD
  - `cl_main.c` — Cheat_CreateMove, Cheat_Init, Cheat_Shutdown
  - `cl_view.c` — Cheat_Frame
  - `in_keys.c` — Cheat_KeyEvent

## Сборка Android

```bash
# как в оригинальном README / Documentation
python3 waf configure -T release --enable-android
python3 waf build
# или android/ gradle flow из репозитория
```

## В игре

- INSERT / volume — меню
- консоль: `cheat_menu`, `cheat_save`, `cheat_load`
- конфиг: `cheat_default.cfg` в gamedir

ESP / Aimbot / Triggerbot — всё на реальных API движка.
