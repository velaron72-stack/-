#include "cheat.h"
#include "keydefs.h"

cheat_cfg_t    g_cheat;
cheat_player_t g_cheat_players[CHEAT_MAX_PLAYERS];
int            g_cheat_local;


static void Cheat_Cmd_ToggleMenu( void )
{
	g_cheat.menu_open = !g_cheat.menu_open;
}

static void Cheat_Cmd_Save( void )
{
	Cheat_Config_Save( "default" );
}

static void Cheat_Cmd_Load( void )
{
	Cheat_Config_Load( "default" );
}

void Cheat_Init( void )
{
	Cheat_Config_Defaults();
	Cmd_AddCommand( "cheat_menu", Cheat_Cmd_ToggleMenu, "toggle cheat menu" );
	Cmd_AddCommand( "cheat_save", Cheat_Cmd_Save, "save cheat config" );
	Cmd_AddCommand( "cheat_load", Cheat_Cmd_Load, "load cheat config" );
	Con_Printf( "[cheat] engine module %s ready\n", CHEAT_VERSION );
}

void Cheat_Shutdown( void )
{
}

void Cheat_Frame( void )
{
	if( cls.state != ca_active )
		return;
	Cheat_ESP_Update();
}

void Cheat_Draw( void )
{
	if( cls.state != ca_active )
		return;
	Cheat_ESP_Draw();
	Cheat_Menu_Draw();
}

void Cheat_CreateMove( usercmd_t *cmd )
{
	if( cls.state != ca_active || !cmd )
		return;
	Cheat_Aim_Run( cmd );
	Cheat_Trig_Run( cmd );
}

void Cheat_KeyEvent( int key, int down )
{
	Cheat_Menu_Key( key, down );
}

void Cheat_Touch( int type, int finger, float x, float y )
{
	(void)finger;
	if( type == 0 ) /* down */
		Cheat_Menu_Touch( (int)( x * refState.width ), (int)( y * refState.height ), 1 );
}
