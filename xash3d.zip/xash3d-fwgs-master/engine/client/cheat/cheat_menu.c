#include "cheat.h"
#include "keydefs.h"

enum { TAB_ESP, TAB_AIM, TAB_TRIG, TAB_CFG, TAB_COUNT };

static int s_tab = TAB_ESP;
static int s_sel = 0;

typedef struct {
	const char *label;
	int type; /* 0 bool 1 float 2 int 4 action */
	void *ptr;
	float minv, maxv, step;
} item_t;

static item_t *s_items;
static int s_count;

static void BuildESP( void )
{
	static item_t it[] = {
		{ "ESP Enabled", 0, &g_cheat.esp.enabled, 0,0,0 },
		{ "Box", 0, &g_cheat.esp.box, 0,0,0 },
		{ "Name", 0, &g_cheat.esp.name, 0,0,0 },
		{ "Health", 0, &g_cheat.esp.health, 0,0,0 },
		{ "Armor", 0, &g_cheat.esp.armor, 0,0,0 },
		{ "Distance", 0, &g_cheat.esp.distance, 0,0,0 },
		{ "Weapon", 0, &g_cheat.esp.weapon, 0,0,0 },
		{ "Skeleton", 0, &g_cheat.esp.skeleton, 0,0,0 },
		{ "Snaplines", 0, &g_cheat.esp.snaplines, 0,0,0 },
		{ "View Dir", 0, &g_cheat.esp.view_dir, 0,0,0 },
		{ "Visible Only", 0, &g_cheat.esp.visible_only, 0,0,0 },
		{ "Show Invisible", 0, &g_cheat.esp.show_invisible, 0,0,0 },
		{ "Max Distance", 1, &g_cheat.esp.max_distance, 0, 5000, 50 },
		{ "Box Thick", 1, &g_cheat.esp.box_thickness, 0.5f, 5, 0.1f },
		{ "Line Thick", 1, &g_cheat.esp.line_thickness, 0.5f, 5, 0.1f },
		{ "Text Scale", 1, &g_cheat.esp.text_scale, 0.5f, 2, 0.05f },
	};
	s_items = it; s_count = sizeof( it ) / sizeof( it[0] );
}

static void BuildAim( void )
{
	static item_t it[] = {
		{ "Aimbot Enabled", 0, &g_cheat.aim.enabled, 0,0,0 },
		{ "Silent", 0, &g_cheat.aim.silent, 0,0,0 },
		{ "Visible Only", 0, &g_cheat.aim.visible_only, 0,0,0 },
		{ "FOV", 1, &g_cheat.aim.fov, 1, 180, 1 },
		{ "Max Distance", 1, &g_cheat.aim.max_distance, 0, 5000, 50 },
		{ "Smoothness", 1, &g_cheat.aim.smoothness, 0, 0.99f, 0.01f },
		{ "Speed", 1, &g_cheat.aim.speed, 0.1f, 10, 0.1f },
		{ "Reaction Delay", 1, &g_cheat.aim.reaction_delay, 0, 1, 0.01f },
		{ "Bone 0H 1C 2S", 2, &g_cheat.aim.bone, 0, 2, 1 },
		{ "Prio 0D 1F 2H", 2, &g_cheat.aim.priority, 0, 2, 1 },
		{ "Switch Target", 0, &g_cheat.aim.switch_target, 0,0,0 },
		{ "Switch Delay", 1, &g_cheat.aim.switch_delay, 0, 2, 0.05f },
	};
	s_items = it; s_count = sizeof( it ) / sizeof( it[0] );
}

static void BuildTrig( void )
{
	static item_t it[] = {
		{ "Trigger Enabled", 0, &g_cheat.trig.enabled, 0,0,0 },
		{ "Delay ms", 1, &g_cheat.trig.delay_ms, 0, 500, 5 },
		{ "Visible Only", 0, &g_cheat.trig.visible_only, 0,0,0 },
		{ "Enemies Only", 0, &g_cheat.trig.enemies_only, 0,0,0 },
		{ "Max Distance", 1, &g_cheat.trig.max_distance, 0, 5000, 50 },
	};
	s_items = it; s_count = sizeof( it ) / sizeof( it[0] );
}

static void BuildCfg( void )
{
	static item_t it[] = {
		{ "Save Config", 4, NULL, 0,0,0 },
		{ "Load Config", 4, NULL, 0,0,0 },
		{ "Reset Defaults", 4, NULL, 0,0,0 },
	};
	s_items = it; s_count = sizeof( it ) / sizeof( it[0] );
}

static void Refresh( void )
{
	switch( s_tab )
	{
	case TAB_ESP: BuildESP(); break;
	case TAB_AIM: BuildAim(); break;
	case TAB_TRIG: BuildTrig(); break;
	case TAB_CFG: BuildCfg(); break;
	default: s_items = NULL; s_count = 0; break;
	}
	if( s_sel >= s_count ) s_sel = 0;
}

void Cheat_Menu_Draw( void )
{
	float scale, mx, my, mw, mh, row, iy;
	cheat_color_t bg, border, sel, text, dim;
	const char *tabs[] = { "ESP", "Aim", "Trig", "Cfg" };
	int i;
	char buf[96];

	if( !g_cheat.menu_open )
		return;
	Refresh();

	scale = g_cheat.menu_scale;
	mx = 20 * scale; my = 40 * scale;
	mw = 280 * scale; mh = 360 * scale;
	row = 22 * scale;

	bg.r = 0.05f; bg.g = 0.05f; bg.b = 0.08f; bg.a = 0.92f;
	border.r = 0.2f; border.g = 0.6f; border.b = 1; border.a = 1;
	sel.r = 0.15f; sel.g = 0.35f; sel.b = 0.7f; sel.a = 0.9f;
	text.r = text.g = text.b = text.a = 1;
	dim.r = dim.g = 0.7f; dim.b = 0.75f; dim.a = 1;

	Cheat_DrawFilled( mx, my, mw, mh, bg );
	Cheat_DrawBox( mx, my, mw, mh, 2, border );

	{
		float tw = mw / TAB_COUNT;
		for( i = 0; i < TAB_COUNT; i++ )
		{
			float tx = mx + i * tw;
			cheat_color_t tc = ( i == s_tab ) ? sel : bg;
			Cheat_DrawFilled( tx, my, tw, 28 * scale, tc );
			Cheat_DrawString( tx + 8 * scale, my + 6 * scale, tabs[i], text );
		}
	}

	iy = my + 36 * scale;
	for( i = 0; i < s_count; i++ )
	{
		float y = iy + i * row;
		item_t *it = &s_items[i];
		if( i == s_sel )
			Cheat_DrawFilled( mx + 4, y, mw - 8, row - 2, sel );
		if( it->type == 0 )
			Q_snprintf( buf, sizeof( buf ), "%s: %s", it->label, *(qboolean *)it->ptr ? "ON" : "OFF" );
		else if( it->type == 1 )
			Q_snprintf( buf, sizeof( buf ), "%s: %.2f", it->label, *(float *)it->ptr );
		else if( it->type == 2 )
			Q_snprintf( buf, sizeof( buf ), "%s: %d", it->label, *(int *)it->ptr );
		else
			Q_snprintf( buf, sizeof( buf ), "%s", it->label );
		Cheat_DrawString( mx + 12 * scale, y + 4 * scale, buf, i == s_sel ? text : dim );
	}
	Cheat_DrawString( mx + 8, my + mh - 20 * scale, "Touch/Keys nav  ENTER toggle", dim );
}

void Cheat_Menu_Key( int key, int down )
{
	if( !down )
		return;
	if( key == g_cheat.menu_key )
	{
		g_cheat.menu_open = !g_cheat.menu_open;
		return;
	}
	if( !g_cheat.menu_open )
		return;
	Refresh();
	if( key == K_UPARROW || key == K_MWHEELUP )
	{
		s_sel--;
		if( s_sel < 0 ) s_sel = s_count - 1;
	}
	else if( key == K_DOWNARROW || key == K_MWHEELDOWN )
	{
		s_sel++;
		if( s_sel >= s_count ) s_sel = 0;
	}
	else if( key == K_LEFTARROW )
	{
		s_tab--;
		if( s_tab < 0 ) s_tab = TAB_COUNT - 1;
		s_sel = 0;
	}
	else if( key == K_RIGHTARROW )
	{
		s_tab++;
		if( s_tab >= TAB_COUNT ) s_tab = 0;
		s_sel = 0;
	}
	else if( key == K_ENTER || key == K_MOUSE1 )
	{
		item_t *it;
		if( s_sel < 0 || s_sel >= s_count ) return;
		it = &s_items[s_sel];
		if( it->type == 0 )
			*(qboolean *)it->ptr = !*(qboolean *)it->ptr;
		else if( it->type == 1 )
		{
			float *v = (float *)it->ptr;
			*v += it->step;
			if( *v > it->maxv ) *v = it->minv;
		}
		else if( it->type == 2 )
		{
			int *v = (int *)it->ptr;
			*v += (int)it->step;
			if( *v > (int)it->maxv ) *v = (int)it->minv;
		}
		else if( it->type == 4 )
		{
			if( s_sel == 0 ) Cheat_Config_Save( "default" );
			else if( s_sel == 1 ) Cheat_Config_Load( "default" );
			else if( s_sel == 2 ) Cheat_Config_Defaults();
		}
	}
}

void Cheat_Menu_Touch( int x, int y, int down )
{
	float scale, mx, my, mw, mh, row, iy;
	if( !down ) return;
	if( !g_cheat.menu_open )
	{
		if( x > refState.width - 80 && y < 80 )
			g_cheat.menu_open = true;
		return;
	}
	scale = g_cheat.menu_scale;
	mx = 20 * scale; my = 40 * scale;
	mw = 280 * scale; mh = 360 * scale;
	row = 22 * scale;
	if( y >= my && y < my + 28 * scale )
	{
		float tw = mw / TAB_COUNT;
		int t = (int)(( x - mx ) / tw );
		if( t >= 0 && t < TAB_COUNT ) { s_tab = t; s_sel = 0; }
		return;
	}
	iy = my + 36 * scale;
	{
		int idx = (int)(( y - iy ) / row );
		if( idx >= 0 && idx < s_count )
		{
			s_sel = idx;
			Cheat_Menu_Key( K_ENTER, 1 );
		}
	}
}
