#include "cheat.h"
#include "mathlib.h"

static void BonePos( cl_entity_t *ent, cheat_bone_t bone, vec3_t out )
{
	float h = 72.0f;
	if( ent->curstate.usehull == 1 )
		h = 36.0f;
	VectorCopy( ent->origin, out );
	switch( bone )
	{
	case CHEAT_BONE_HEAD:    out[2] += h * 0.92f; break;
	case CHEAT_BONE_CHEST:   out[2] += h * 0.65f; break;
	case CHEAT_BONE_STOMACH: out[2] += h * 0.45f; break;
	default:                 out[2] += h * 0.75f; break;
	}
}

void Cheat_ESP_Update( void )
{
	cl_entity_t *local;
	int i, maxc;

	local = CL_GetLocalPlayer();
	if( !local )
		return;
	g_cheat_local = local->index;

	maxc = cl.maxclients;
	if( maxc > CHEAT_MAX_PLAYERS )
		maxc = CHEAT_MAX_PLAYERS;

	for( i = 1; i <= maxc; i++ )
	{
		cheat_player_t *p = &g_cheat_players[i];
		cl_entity_t *ent;
		memset( p, 0, sizeof( *p ));
		p->index = i;
		if( i == g_cheat_local )
			continue;

		ent = CL_GetEntityByIndex( i );
		if( !ent || !ent->player )
			continue;
		if( !ent->curstate.messagenum )
			continue;

		p->valid = true;
		p->alive = ( ent->curstate.health > 0 ) && !( ent->curstate.effects & EF_NODRAW );
		if( !p->alive )
			continue;

		VectorCopy( ent->origin, p->origin );
		VectorCopy( ent->angles, p->angles );
		BonePos( ent, CHEAT_BONE_HEAD, p->head );
		BonePos( ent, CHEAT_BONE_CHEST, p->chest );
		p->health = (float)ent->curstate.health;
		p->team = ent->curstate.team;
		p->enemy = ( p->team != local->curstate.team ) || ( p->team == 0 );
		p->dist = Cheat_Dist( local->origin, p->origin );
		p->visible = Cheat_IsVisible( local->origin, p->head, g_cheat_local );

		{
			int pi = i - 1;
			if( pi >= 0 && pi < cl.maxclients && cl.players[pi].name[0] )
				Q_strncpy( p->name, cl.players[pi].name, sizeof( p->name ));
			else
				Q_snprintf( p->name, sizeof( p->name ), "Player %d", i );
		}
		if( ent->curstate.weaponmodel )
			Q_snprintf( p->weapon, sizeof( p->weapon ), "wpn_%d", ent->curstate.weaponmodel );
		else
			Q_strncpy( p->weapon, "?", sizeof( p->weapon ));
	}
}

static void DrawOne( const cheat_player_t *p )
{
	float sx, sy, tx, ty, h, w, x, y, liney;
	cheat_color_t col;
	char buf[64];

	if( !p->valid || !p->alive )
		return;
	if( g_cheat.esp.max_distance > 0 && p->dist > g_cheat.esp.max_distance )
		return;
	if( g_cheat.esp.visible_only && !p->visible )
		return;
	if( !g_cheat.esp.show_invisible && !p->visible )
		return;

	if( !Cheat_WorldToScreen( p->origin, &sx, &sy ))
		return;
	{
		vec3_t top;
		VectorCopy( p->origin, top );
		top[2] += 72.0f;
		if( !Cheat_WorldToScreen( top, &tx, &ty ))
			return;
	}

	h = fabs( ty - sy );
	w = h * 0.45f;
	x = sx - w * 0.5f;
	y = ty;
	col = p->visible ? g_cheat.esp.box_vis : g_cheat.esp.box_invis;

	if( g_cheat.esp.box )
		Cheat_DrawBox( x, y, w, h, g_cheat.esp.box_thickness, col );

	if( g_cheat.esp.snaplines )
		Cheat_DrawLine( refState.width * 0.5f, (float)refState.height, sx, sy,
			g_cheat.esp.line_thickness, g_cheat.esp.snap_col );

	if( g_cheat.esp.view_dir )
	{
		vec3_t end;
		float yaw = p->angles[1] * (float)M_PI / 180.0f;
		end[0] = p->origin[0] + cos( yaw ) * 40.0f;
		end[1] = p->origin[1] + sin( yaw ) * 40.0f;
		end[2] = p->origin[2] + 40.0f;
		{
			float ex, ey;
			if( Cheat_WorldToScreen( end, &ex, &ey ))
				Cheat_DrawLine( sx, sy - h * 0.5f, ex, ey, 1.5f, g_cheat.esp.view_col );
		}
	}

	liney = y - 14.0f * g_cheat.esp.text_scale;
	if( g_cheat.esp.name )
	{
		Cheat_DrawString( x, liney, p->name, g_cheat.esp.name_col );
		liney -= 12.0f * g_cheat.esp.text_scale;
	}
	if( g_cheat.esp.health )
	{
		Q_snprintf( buf, sizeof( buf ), "HP: %.0f", p->health );
		Cheat_DrawString( x, liney, buf, g_cheat.esp.hp_col );
		liney -= 12.0f * g_cheat.esp.text_scale;
	}
	if( g_cheat.esp.armor )
	{
		Q_snprintf( buf, sizeof( buf ), "AR: %.0f", p->armor );
		Cheat_DrawString( x, liney, buf, g_cheat.esp.armor_col );
		liney -= 12.0f * g_cheat.esp.text_scale;
	}
	if( g_cheat.esp.distance )
	{
		Q_snprintf( buf, sizeof( buf ), "%.0f u", p->dist );
		Cheat_DrawString( x, liney, buf, g_cheat.esp.name_col );
		liney -= 12.0f * g_cheat.esp.text_scale;
	}
	if( g_cheat.esp.weapon )
		Cheat_DrawString( x, liney, p->weapon, g_cheat.esp.name_col );

	if( g_cheat.esp.skeleton )
	{
		float hx, hy, cx, cy, px, py;
		if( Cheat_WorldToScreen( p->head, &hx, &hy ) &&
		    Cheat_WorldToScreen( p->chest, &cx, &cy ) &&
		    Cheat_WorldToScreen( p->origin, &px, &py ))
		{
			Cheat_DrawLine( hx, hy, cx, cy, 1.2f, g_cheat.esp.skel_col );
			Cheat_DrawLine( cx, cy, px, py, 1.2f, g_cheat.esp.skel_col );
		}
	}
}

void Cheat_ESP_Draw( void )
{
	int i;
	if( !g_cheat.esp.enabled )
		return;
	for( i = 1; i < CHEAT_MAX_PLAYERS; i++ )
		DrawOne( &g_cheat_players[i] );
}
