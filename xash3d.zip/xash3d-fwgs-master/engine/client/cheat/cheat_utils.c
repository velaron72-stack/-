#include "cheat.h"
#include "mathlib.h"

/* engine provides these */
extern triangleapi_t gTriApi;
extern ref_globals_t refState;

float Cheat_Dist( const vec3_t a, const vec3_t b )
{
	vec3_t d;
	VectorSubtract( a, b, d );
	return VectorLength( d );
}

void Cheat_VectorAngles( const vec3_t forward, vec3_t angles )
{
	float tmp, yaw, pitch;

	if( forward[1] == 0 && forward[0] == 0 )
	{
		yaw = 0;
		pitch = forward[2] > 0 ? 90.0f : 270.0f;
	}
	else
	{
		yaw = (float)( atan2( forward[1], forward[0] ) * 180.0 / M_PI );
		if( yaw < 0 ) yaw += 360.0f;
		tmp = (float)sqrt( forward[0] * forward[0] + forward[1] * forward[1] );
		pitch = (float)( atan2( forward[2], tmp ) * 180.0 / M_PI );
	}
	angles[0] = -pitch;
	angles[1] = yaw;
	angles[2] = 0;
}

float Cheat_AngleDiff( float a, float b )
{
	float d = a - b;
	while( d > 180.0f ) d -= 360.0f;
	while( d < -180.0f ) d += 360.0f;
	return d;
}

void Cheat_NormalizeAngles( vec3_t a )
{
	int i;
	for( i = 0; i < 3; i++ )
	{
		while( a[i] > 180.0f ) a[i] -= 360.0f;
		while( a[i] < -180.0f ) a[i] += 360.0f;
	}
}

qboolean Cheat_WorldToScreen( const vec3_t world, float *sx, float *sy )
{
	vec3_t screen;
	if( !ref.dllFuncs.WorldToScreen )
		return false;
	if( ref.dllFuncs.WorldToScreen( (float *)world, screen ))
		return false;
	*sx = ( 1.0f + screen[0] ) * refState.width  * 0.5f;
	*sy = ( 1.0f - screen[1] ) * refState.height * 0.5f;
	return true;
}

qboolean Cheat_IsVisible( const vec3_t start, const vec3_t end, int ignore )
{
	pmtrace_t *tr;
	if( !clgame.pmove )
		return true;
	tr = PM_TraceLine( clgame.pmove, (float *)start, (float *)end, PM_TRACELINE_ANYVISIBLE, 2, ignore );
	if( !tr )
		return true;
	return tr->fraction >= 0.97f;
}

void Cheat_DrawLine( float x1, float y1, float x2, float y2, float thick, cheat_color_t c )
{
	(void)thick;
	gTriApi.RenderMode( kRenderTransAlpha );
	gTriApi.Color4f( c.r, c.g, c.b, c.a );
	gTriApi.Begin( TRI_LINES );
	gTriApi.Vertex3f( x1, y1, 0 );
	gTriApi.Vertex3f( x2, y2, 0 );
	gTriApi.End();
}

void Cheat_DrawBox( float x, float y, float w, float h, float thick, cheat_color_t c )
{
	Cheat_DrawLine( x,     y,     x + w, y,     thick, c );
	Cheat_DrawLine( x,     y + h, x + w, y + h, thick, c );
	Cheat_DrawLine( x,     y,     x,     y + h, thick, c );
	Cheat_DrawLine( x + w, y,     x + w, y + h, thick, c );
}

void Cheat_DrawFilled( float x, float y, float w, float h, cheat_color_t c )
{
	gTriApi.RenderMode( kRenderTransAlpha );
	gTriApi.Color4f( c.r, c.g, c.b, c.a );
	gTriApi.Begin( TRI_QUADS );
	gTriApi.Vertex3f( x,     y,     0 );
	gTriApi.Vertex3f( x + w, y,     0 );
	gTriApi.Vertex3f( x + w, y + h, 0 );
	gTriApi.Vertex3f( x,     y + h, 0 );
	gTriApi.End();
}

void Cheat_DrawString( float x, float y, const char *s, cheat_color_t c )
{
	rgba_t col;
	col[0] = (byte)( c.r * 255.0f );
	col[1] = (byte)( c.g * 255.0f );
	col[2] = (byte)( c.b * 255.0f );
	col[3] = (byte)( c.a * 255.0f );
	Con_DrawString( (int)x, (int)y, s, col );
}
