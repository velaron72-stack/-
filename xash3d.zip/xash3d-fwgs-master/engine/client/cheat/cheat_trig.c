#include "cheat.h"
#include "mathlib.h"

static float s_ready = 0;

void Cheat_Trig_Run( usercmd_t *cmd )
{
	int i, hit = -1;
	float best = 2.5f;
	float now;
	cl_entity_t *local;
	vec3_t vieworg;

	if( !g_cheat.trig.enabled || !cmd )
		return;
	local = CL_GetLocalPlayer();
	if( !local )
		return;
	VectorCopy( local->origin, vieworg );
	vieworg[2] += 28.0f;
	now = cl.time;

	for( i = 1; i < CHEAT_MAX_PLAYERS; i++ )
	{
		cheat_player_t *p = &g_cheat_players[i];
		vec3_t dir, ang;
		float dy, dp, fov;

		if( !p->valid || !p->alive )
			continue;
		if( g_cheat.trig.enemies_only && !p->enemy )
			continue;
		if( g_cheat.trig.visible_only && !p->visible )
			continue;
		if( g_cheat.trig.max_distance > 0 && p->dist > g_cheat.trig.max_distance )
			continue;

		VectorSubtract( p->head, vieworg, dir );
		Cheat_VectorAngles( dir, ang );
		dy = Cheat_AngleDiff( ang[1], cmd->viewangles[1] );
		dp = Cheat_AngleDiff( ang[0], cmd->viewangles[0] );
		fov = sqrtf( dy * dy + dp * dp );
		if( fov < best )
		{
			best = fov;
			hit = i;
		}
	}

	if( hit < 0 )
	{
		s_ready = 0;
		return;
	}
	if( s_ready <= 0 )
		s_ready = now + g_cheat.trig.delay_ms / 1000.0f;
	if( now >= s_ready )
	{
		cmd->buttons |= IN_ATTACK;
		s_ready = 0;
	}
}
