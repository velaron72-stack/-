#pragma once

/*
 * Xash3D FWGS internal cheat module
 * Lives inside engine/client — rebuilt with the engine.
 */

#include "common.h"
#include "client.h"
#include "const.h"
#include "cl_entity.h"
#include "ref_api.h"
#include "triangleapi.h"
#include "keydefs.h"
#include "mathlib.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CHEAT_MAX_PLAYERS   64
#define CHEAT_VERSION       "engine-1.0"

typedef struct {
	float r, g, b, a;
} cheat_color_t;

typedef struct {
	qboolean enabled;
	qboolean box;
	qboolean name;
	qboolean health;
	qboolean armor;
	qboolean distance;
	qboolean weapon;
	qboolean skeleton;
	qboolean snaplines;
	qboolean view_dir;
	qboolean visible_only;
	qboolean show_invisible;
	float    max_distance;
	float    box_thickness;
	float    line_thickness;
	float    text_scale;
	cheat_color_t box_vis;
	cheat_color_t box_invis;
	cheat_color_t name_col;
	cheat_color_t hp_col;
	cheat_color_t armor_col;
	cheat_color_t snap_col;
	cheat_color_t skel_col;
	cheat_color_t view_col;
} cheat_esp_t;

typedef enum {
	CHEAT_BONE_HEAD = 0,
	CHEAT_BONE_CHEST,
	CHEAT_BONE_STOMACH,
	CHEAT_BONE_COUNT
} cheat_bone_t;

typedef enum {
	CHEAT_PRIO_DIST = 0,
	CHEAT_PRIO_FOV,
	CHEAT_PRIO_HP,
	CHEAT_PRIO_COUNT
} cheat_prio_t;

typedef struct {
	qboolean enabled;
	qboolean silent;
	qboolean visible_only;
	float    fov;
	float    max_distance;
	float    smoothness;
	float    speed;
	float    reaction_delay;
	cheat_bone_t bone;
	cheat_prio_t priority;
	qboolean switch_target;
	float    switch_delay;
} cheat_aim_t;

typedef struct {
	qboolean enabled;
	float    delay_ms;
	qboolean visible_only;
	qboolean enemies_only;
	float    max_distance;
} cheat_trig_t;

typedef struct {
	cheat_esp_t  esp;
	cheat_aim_t  aim;
	cheat_trig_t trig;
	int          menu_key;
	qboolean     menu_open;
	float        menu_scale;
	char         cfg_name[64];
} cheat_cfg_t;

typedef struct {
	int      index;
	qboolean valid;
	qboolean alive;
	qboolean enemy;
	qboolean visible;
	vec3_t   origin;
	vec3_t   angles;
	vec3_t   head;
	vec3_t   chest;
	float    health;
	float    armor;
	float    dist;
	char     name[32];
	char     weapon[32];
	int      team;
} cheat_player_t;

extern cheat_cfg_t    g_cheat;
extern cheat_player_t g_cheat_players[CHEAT_MAX_PLAYERS];
extern int            g_cheat_local;

void Cheat_Init( void );
void Cheat_Shutdown( void );
void Cheat_Frame( void );
void Cheat_Draw( void );
void Cheat_CreateMove( usercmd_t *cmd );
void Cheat_KeyEvent( int key, int down );
void Cheat_Touch( int type, int finger, float x, float y );

void Cheat_ESP_Update( void );
void Cheat_ESP_Draw( void );
void Cheat_Aim_Run( usercmd_t *cmd );
void Cheat_Trig_Run( usercmd_t *cmd );
void Cheat_Menu_Draw( void );
void Cheat_Menu_Key( int key, int down );
void Cheat_Menu_Touch( int x, int y, int down );

void Cheat_Config_Defaults( void );
void Cheat_Config_Save( const char *name );
void Cheat_Config_Load( const char *name );

float Cheat_Dist( const vec3_t a, const vec3_t b );
void  Cheat_VectorAngles( const vec3_t forward, vec3_t angles );
float Cheat_AngleDiff( float a, float b );
void  Cheat_NormalizeAngles( vec3_t a );
qboolean Cheat_WorldToScreen( const vec3_t world, float *sx, float *sy );
qboolean Cheat_IsVisible( const vec3_t start, const vec3_t end, int ignore );
void  Cheat_DrawBox( float x, float y, float w, float h, float thick, cheat_color_t c );
void  Cheat_DrawLine( float x1, float y1, float x2, float y2, float thick, cheat_color_t c );
void  Cheat_DrawString( float x, float y, const char *s, cheat_color_t c );
void  Cheat_DrawFilled( float x, float y, float w, float h, cheat_color_t c );

#ifdef __cplusplus
}
#endif
