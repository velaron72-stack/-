#include "cheat.h"

void Cheat_Config_Defaults( void )
{
	memset( &g_cheat, 0, sizeof( g_cheat ));

	g_cheat.esp.enabled = true;
	g_cheat.esp.box = true;
	g_cheat.esp.name = true;
	g_cheat.esp.health = true;
	g_cheat.esp.distance = true;
	g_cheat.esp.snaplines = true;
	g_cheat.esp.show_invisible = true;
	g_cheat.esp.max_distance = 3000;
	g_cheat.esp.box_thickness = 1.5f;
	g_cheat.esp.line_thickness = 1.2f;
	g_cheat.esp.text_scale = 1.0f;
	g_cheat.esp.box_vis = (cheat_color_t){ 0.1f, 1.0f, 0.2f, 0.9f };
	g_cheat.esp.box_invis = (cheat_color_t){ 1.0f, 0.2f, 0.15f, 0.85f };
	g_cheat.esp.name_col = (cheat_color_t){ 1,1,1,1 };
	g_cheat.esp.hp_col = (cheat_color_t){ 0.2f,1,0.3f,1 };
	g_cheat.esp.armor_col = (cheat_color_t){ 0.3f,0.6f,1,1 };
	g_cheat.esp.snap_col = (cheat_color_t){ 1,1,0.2f,0.7f };
	g_cheat.esp.skel_col = (cheat_color_t){ 1,1,1,0.8f };
	g_cheat.esp.view_col = (cheat_color_t){ 0.8f,0.4f,1,0.9f };

	g_cheat.aim.enabled = false;
	g_cheat.aim.visible_only = true;
	g_cheat.aim.fov = 8.0f;
	g_cheat.aim.max_distance = 2500;
	g_cheat.aim.smoothness = 0.35f;
	g_cheat.aim.speed = 2.5f;
	g_cheat.aim.reaction_delay = 0.05f;
	g_cheat.aim.bone = CHEAT_BONE_HEAD;
	g_cheat.aim.priority = CHEAT_PRIO_FOV;
	g_cheat.aim.switch_target = true;
	g_cheat.aim.switch_delay = 0.3f;

	g_cheat.trig.enabled = false;
	g_cheat.trig.delay_ms = 30;
	g_cheat.trig.visible_only = true;
	g_cheat.trig.enemies_only = true;
	g_cheat.trig.max_distance = 1500;

	g_cheat.menu_key = K_INSERT;
	g_cheat.menu_scale = 1.2f;
	Q_strncpy( g_cheat.cfg_name, "default", sizeof( g_cheat.cfg_name ));
}

void Cheat_Config_Save( const char *name )
{
	file_t *f;
	char path[128];
	Q_snprintf( path, sizeof( path ), "cheat_%s.cfg", name ? name : "default" );
	f = FS_Open( path, "w", true );
	if( !f ) return;

	FS_Printf( f, "esp_enabled %d\n", g_cheat.esp.enabled );
	FS_Printf( f, "esp_box %d\n", g_cheat.esp.box );
	FS_Printf( f, "esp_name %d\n", g_cheat.esp.name );
	FS_Printf( f, "esp_health %d\n", g_cheat.esp.health );
	FS_Printf( f, "esp_armor %d\n", g_cheat.esp.armor );
	FS_Printf( f, "esp_distance %d\n", g_cheat.esp.distance );
	FS_Printf( f, "esp_weapon %d\n", g_cheat.esp.weapon );
	FS_Printf( f, "esp_skeleton %d\n", g_cheat.esp.skeleton );
	FS_Printf( f, "esp_snaplines %d\n", g_cheat.esp.snaplines );
	FS_Printf( f, "esp_viewdir %d\n", g_cheat.esp.view_dir );
	FS_Printf( f, "esp_visible_only %d\n", g_cheat.esp.visible_only );
	FS_Printf( f, "esp_show_invis %d\n", g_cheat.esp.show_invisible );
	FS_Printf( f, "esp_maxdist %.1f\n", g_cheat.esp.max_distance );
	FS_Printf( f, "esp_boxthick %.2f\n", g_cheat.esp.box_thickness );
	FS_Printf( f, "esp_linethick %.2f\n", g_cheat.esp.line_thickness );
	FS_Printf( f, "esp_textscale %.2f\n", g_cheat.esp.text_scale );

	FS_Printf( f, "aim_enabled %d\n", g_cheat.aim.enabled );
	FS_Printf( f, "aim_silent %d\n", g_cheat.aim.silent );
	FS_Printf( f, "aim_visible %d\n", g_cheat.aim.visible_only );
	FS_Printf( f, "aim_fov %.1f\n", g_cheat.aim.fov );
	FS_Printf( f, "aim_maxdist %.1f\n", g_cheat.aim.max_distance );
	FS_Printf( f, "aim_smooth %.2f\n", g_cheat.aim.smoothness );
	FS_Printf( f, "aim_speed %.2f\n", g_cheat.aim.speed );
	FS_Printf( f, "aim_delay %.2f\n", g_cheat.aim.reaction_delay );
	FS_Printf( f, "aim_bone %d\n", (int)g_cheat.aim.bone );
	FS_Printf( f, "aim_prio %d\n", (int)g_cheat.aim.priority );
	FS_Printf( f, "aim_switch %d\n", g_cheat.aim.switch_target );
	FS_Printf( f, "aim_switchdelay %.2f\n", g_cheat.aim.switch_delay );

	FS_Printf( f, "trig_enabled %d\n", g_cheat.trig.enabled );
	FS_Printf( f, "trig_delay %.1f\n", g_cheat.trig.delay_ms );
	FS_Printf( f, "trig_visible %d\n", g_cheat.trig.visible_only );
	FS_Printf( f, "trig_enemies %d\n", g_cheat.trig.enemies_only );
	FS_Printf( f, "trig_maxdist %.1f\n", g_cheat.trig.max_distance );
	FS_Printf( f, "menu_scale %.2f\n", g_cheat.menu_scale );

	FS_Close( f );
	Con_Printf( "[cheat] saved %s\n", path );
}

static void ApplyKey( const char *key, const char *val )
{
	int ival = Q_atoi( val );
	float fval = Q_atof( val );

	if( !Q_strcmp( key, "esp_enabled" )) g_cheat.esp.enabled = ival;
	else if( !Q_strcmp( key, "esp_box" )) g_cheat.esp.box = ival;
	else if( !Q_strcmp( key, "esp_name" )) g_cheat.esp.name = ival;
	else if( !Q_strcmp( key, "esp_health" )) g_cheat.esp.health = ival;
	else if( !Q_strcmp( key, "esp_armor" )) g_cheat.esp.armor = ival;
	else if( !Q_strcmp( key, "esp_distance" )) g_cheat.esp.distance = ival;
	else if( !Q_strcmp( key, "esp_weapon" )) g_cheat.esp.weapon = ival;
	else if( !Q_strcmp( key, "esp_skeleton" )) g_cheat.esp.skeleton = ival;
	else if( !Q_strcmp( key, "esp_snaplines" )) g_cheat.esp.snaplines = ival;
	else if( !Q_strcmp( key, "esp_viewdir" )) g_cheat.esp.view_dir = ival;
	else if( !Q_strcmp( key, "esp_visible_only" )) g_cheat.esp.visible_only = ival;
	else if( !Q_strcmp( key, "esp_show_invis" )) g_cheat.esp.show_invisible = ival;
	else if( !Q_strcmp( key, "esp_maxdist" )) g_cheat.esp.max_distance = fval;
	else if( !Q_strcmp( key, "esp_boxthick" )) g_cheat.esp.box_thickness = fval;
	else if( !Q_strcmp( key, "esp_linethick" )) g_cheat.esp.line_thickness = fval;
	else if( !Q_strcmp( key, "esp_textscale" )) g_cheat.esp.text_scale = fval;
	else if( !Q_strcmp( key, "aim_enabled" )) g_cheat.aim.enabled = ival;
	else if( !Q_strcmp( key, "aim_silent" )) g_cheat.aim.silent = ival;
	else if( !Q_strcmp( key, "aim_visible" )) g_cheat.aim.visible_only = ival;
	else if( !Q_strcmp( key, "aim_fov" )) g_cheat.aim.fov = fval;
	else if( !Q_strcmp( key, "aim_maxdist" )) g_cheat.aim.max_distance = fval;
	else if( !Q_strcmp( key, "aim_smooth" )) g_cheat.aim.smoothness = fval;
	else if( !Q_strcmp( key, "aim_speed" )) g_cheat.aim.speed = fval;
	else if( !Q_strcmp( key, "aim_delay" )) g_cheat.aim.reaction_delay = fval;
	else if( !Q_strcmp( key, "aim_bone" )) g_cheat.aim.bone = ival;
	else if( !Q_strcmp( key, "aim_prio" )) g_cheat.aim.priority = ival;
	else if( !Q_strcmp( key, "aim_switch" )) g_cheat.aim.switch_target = ival;
	else if( !Q_strcmp( key, "aim_switchdelay" )) g_cheat.aim.switch_delay = fval;
	else if( !Q_strcmp( key, "trig_enabled" )) g_cheat.trig.enabled = ival;
	else if( !Q_strcmp( key, "trig_delay" )) g_cheat.trig.delay_ms = fval;
	else if( !Q_strcmp( key, "trig_visible" )) g_cheat.trig.visible_only = ival;
	else if( !Q_strcmp( key, "trig_enemies" )) g_cheat.trig.enemies_only = ival;
	else if( !Q_strcmp( key, "trig_maxdist" )) g_cheat.trig.max_distance = fval;
	else if( !Q_strcmp( key, "menu_scale" )) g_cheat.menu_scale = fval;
}

void Cheat_Config_Load( const char *name )
{
	file_t *f;
	char path[128], line[256], key[64], val[64];

	Q_snprintf( path, sizeof( path ), "cheat_%s.cfg", name ? name : "default" );
	f = FS_Open( path, "r", true );
	if( !f )
	{
		Cheat_Config_Defaults();
		return;
	}
	while( !FS_Eof( f ))
	{
		if( !FS_Gets( f, line, sizeof( line )))
			break;
		key[0] = val[0] = 0;
		if( sscanf( line, "%63s %63s", key, val ) >= 2 )
			ApplyKey( key, val );
	}
	FS_Close( f );
	Con_Printf( "[cheat] loaded %s\n", path );
}
