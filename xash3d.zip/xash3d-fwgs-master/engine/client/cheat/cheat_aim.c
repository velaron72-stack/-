#include "cheat.h"
#include "mathlib.h"

static int   s_target = -1;
static float s_aim_start = 0;
static float s_last_switch = 0;

static float GetFOV( const vec3_t local_ang, const vec3_t target_pos, const vec3_t vieworg )
{
	vec3_t dir, ang;
	VectorSubtract( target_pos, vieworg, dir );
	Cheat_VectorAngles( dir, ang );
	{
		float dy = Cheat_AngleDiff( ang[1], local_ang[1] );
		float dp = Cheat_AngleDiff( ang[0], local_ang[0] );
		return sqrtf( dy * dy + dp * dp );
	}
}

static int SelectTarget( const vec3_t vieworg, const vec3_t viewang )
{
	int best = -1;
	float best_score = 1e9f;
	float now = cl.time;
	int i;

	for( i = 1; i < CHEAT_MAX_PLAYERS; i++ )
	{
		cheat_player_t *p = &g_cheat_players[i];
		vec3_t aimpos;
		float fov, score;

		if( !p->valid || !p->alive || !p->enemy )
			continue;
		if( g_cheat.aim.visible_only && !p->visible )
			continue;
		if( g_cheat.aim.max_distance > 0 && p->dist > g_cheat.aim.max_distance )
			continue;

		switch( g_cheat.aim.bone )
		{
		case CHEAT_BONE_HEAD:    VectorCopy( p->head, aimpos ); break;
		case CHEAT_BONE_CHEST:   VectorCopy( p->chest, aimpos ); break;
		case CHEAT_BONE_STOMACH:
			VectorCopy( p->origin, aimpos );
			aimpos[2] += 30.0f;
			break;
		default: VectorCopy( p->head, aimpos ); break;
		}

		fov = GetFOV( viewang, aimpos, vieworg );
		if( fov > g_cheat.aim.fov )
			continue;

		switch( g_cheat.aim.priority )
		{
		case CHEAT_PRIO_DIST: score = p->dist; break;
		case CHEAT_PRIO_FOV:  score = fov; break;
		case CHEAT_PRIO_HP:   score = p->health; break;
		default:              score = fov; break;
		}
		if( score < best_score )
		{
			best_score = score;
			best = i;
		}
	}

	if( g_cheat.aim.switch_target && best != s_target )
	{
		if( now - s_last_switch < g_cheat.aim.switch_delay )
			return s_target;
		s_last_switch = now;
	}
	return best;
}

void Cheat_Aim_Run( usercmd_t *cmd )
{
	cl_entity_t *local;
	vec3_t vieworg, viewang, aimpos, dir, target_ang;
	int target;
	float now, factor, dy, dp;

	if( !g_cheat.aim.enabled || !cmd )
		return;
	local = CL_GetLocalPlayer();
	if( !local )
		return;

	VectorCopy( local->origin, vieworg );
	vieworg[2] += 28.0f; /* eye approx */
	VectorCopy( cmd->viewangles, viewang );

	target = SelectTarget( vieworg, viewang );
	if( target < 0 )
	{
		s_target = -1;
		return;
	}

	now = cl.time;
	if( target != s_target )
	{
		s_target = target;
		s_aim_start = now;
	}
	if( now - s_aim_start < g_cheat.aim.reaction_delay )
		return;

	{
		cheat_player_t *p = &g_cheat_players[target];
		switch( g_cheat.aim.bone )
		{
		case CHEAT_BONE_HEAD:    VectorCopy( p->head, aimpos ); break;
		case CHEAT_BONE_CHEST:   VectorCopy( p->chest, aimpos ); break;
		case CHEAT_BONE_STOMACH:
			VectorCopy( p->origin, aimpos );
			aimpos[2] += 30.0f;
			break;
		default: VectorCopy( p->head, aimpos ); break;
		}
	}

	VectorSubtract( aimpos, vieworg, dir );
	Cheat_VectorAngles( dir, target_ang );
	Cheat_NormalizeAngles( target_ang );

	factor = ( 1.0f - bound( 0.0f, g_cheat.aim.smoothness, 0.99f )) * g_cheat.aim.speed * host.frametime * 60.0f;
	if( factor > 1.0f ) factor = 1.0f;

	dy = Cheat_AngleDiff( target_ang[1], viewang[1] );
	dp = Cheat_AngleDiff( target_ang[0], viewang[0] );

	cmd->viewangles[0] = viewang[0] + dp * factor;
	cmd->viewangles[1] = viewang[1] + dy * factor;
	cmd->viewangles[2] = 0;

	if( !g_cheat.aim.silent )
	{
		cl.viewangles[0] = cmd->viewangles[0];
		cl.viewangles[1] = cmd->viewangles[1];
		cl.viewangles[2] = 0;
	}
}
