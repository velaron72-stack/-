/*
vgui_api.h - vgui_support library interface
Copyright (C) 2015 Mittorn

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>
*/
#ifndef VGUI_API_H
#define VGUI_API_H

#include <stddef.h>
#include "key_modifiers.h"
#include "cursor_type.h"

// VGUI generic vertex

typedef struct
{
	float	point[2];
	float	coord[2];
} vpoint_t;

// C-Style VGUI enums

enum VGUI_MouseCode
{
	MOUSE_LEFT=0,
	MOUSE_RIGHT,
	MOUSE_MIDDLE,
	MOUSE_LAST
};

enum VGUI_KeyCode
{
	KEY_0=0,
	KEY_1,
	KEY_2,
	KEY_3,
	KEY_4,
	KEY_5,
	KEY_6,
	KEY_7,
	KEY_8,
	KEY_9,
	KEY_A,
	KEY_B,
	KEY_C,
	KEY_D,
	KEY_E,
	KEY_F,
	KEY_G,
	KEY_H,
	KEY_I,
	KEY_J,
	KEY_K,
	KEY_L,
	KEY_M,
	KEY_N,
	KEY_O,
	KEY_P,
	KEY_Q,
	KEY_R,
	KEY_S,
	KEY_T,
	KEY_U,
	KEY_V,
	KEY_W,
	KEY_X,
	KEY_Y,
	KEY_Z,
	KEY_PAD_0,
	KEY_PAD_1,
	KEY_PAD_2,
	KEY_PAD_3,
	KEY_PAD_4,
	KEY_PAD_5,
	KEY_PAD_6,
	KEY_PAD_7,
	KEY_PAD_8,
	KEY_PAD_9,
	KEY_PAD_DIVIDE,
	KEY_PAD_MULTIPLY,
	KEY_PAD_MINUS,
	KEY_PAD_PLUS,
	KEY_PAD_ENTER,
	KEY_PAD_DECIMAL,
	KEY_LBRACKET,
	KEY_RBRACKET,
	KEY_SEMICOLON,
	KEY_APOSTROPHE,
	KEY_BACKQUOTE,
	KEY_COMMA,
	KEY_PERIOD,
	KEY_SLASH,
	KEY_BACKSLASH,
	KEY_MINUS,
	KEY_EQUAL,
	KEY_ENTER,
	KEY_SPACE,
	KEY_BACKSPACE,
	KEY_TAB,
	KEY_CAPSLOCK,
	KEY_NUMLOCK,
	KEY_ESCAPE,
	KEY_SCROLLLOCK,
	KEY_INSERT,
	KEY_DELETE,
	KEY_HOME,
	KEY_END,
	KEY_PAGEUP,
	KEY_PAGEDOWN,
	KEY_BREAK,
	KEY_LSHIFT,
	KEY_RSHIFT,
	KEY_LALT,
	KEY_RALT,
	KEY_LCONTROL,
	KEY_RCONTROL,
	KEY_LWIN,
	KEY_RWIN,
	KEY_APP,
	KEY_UP,
	KEY_LEFT,
	KEY_DOWN,
	KEY_RIGHT,
	KEY_F1,
	KEY_F2,
	KEY_F3,
	KEY_F4,
	KEY_F5,
	KEY_F6,
	KEY_F7,
	KEY_F8,
	KEY_F9,
	KEY_F10,
	KEY_F11,
	KEY_F12,
	KEY_LAST
};

enum VGUI_KeyAction
{
	KA_TYPED=0,
	KA_PRESSED,
	KA_RELEASED
};
enum VGUI_MouseAction
{
	MA_PRESSED=0,
	MA_RELEASED,
	MA_DOUBLE,
	MA_WHEEL
};

typedef struct  vguiapi_s
{
	int	initialized;
	// called from vgui_support
	void	(*DrawInit)( void );
	void	(*DrawShutdown)( void );
	void	(*SetupDrawingText)( int *pColor );
	void	(*SetupDrawingRect)( int *pColor );
	void	(*SetupDrawingImage)( int *pColor );
	void	(*BindTexture)( int id );
	void	(*EnableTexture)( int enable );
	void	(*Reserved0)( int id, int width, int height );
	void	(*UploadTexture)( int id, const char *buffer, int width, int height );
	void	(*Reserved1)( int id, int drawX, int drawY, const unsigned char *rgba, int blockWidth, int blockHeight );
	void	(*DrawQuad)( const vpoint_t *ul, const vpoint_t *lr );
	void	(*GetTextureSizes)( int *width, int *height );
	int		(*GenerateTexture)( void );
	void	*(*EngineMalloc)( size_t size );
	void	(*CursorSelect)( VGUI_DefaultCursor cursor );
	unsigned char	(*GetColor)( int i, int j );
	int		(*IsInGame)( void );
	void	(*EnableTextInput)( int enable, int force );
	void	(*GetCursorPos)( int *x, int *y );
	int		(*ProcessUtfChar)( int ch );
	int		(*GetClipboardText)( char *buffer, size_t bufferSize );
	void	(*SetClipboardText)( const char *text );
	key_modifier_t (*GetKeyModifiers)( void );
	// called from engine side
	void	(*Startup)( int width, int height );
	void	(*Shutdown)( void );
	void	*(*GetPanel)( void );
	void	(*Paint)( void );
	void	(*Mouse)( enum VGUI_MouseAction action, int code );
	void	(*Key)( enum VGUI_KeyAction action, enum VGUI_KeyCode code );
	void	(*MouseMove)( int x, int y );
	void	(*TextInput)( const char *text );

	// called from vgui_support, appended later so older support libraries keep working
	void	(*SetPaintOffset)( int x, int y );	// translates 2D drawing for the everything that's not VGUI, used to simulate GoldSrc behavior which installs matrix in push/popMakeCurrent
} vguiapi_t;
#endif // VGUI_API_H
